#include "Optimizer.hpp"

namespace SoftWire
{
	Optimizer::Optimizer()
	{
	}

	Optimizer::~Optimizer()
	{
	}

	Encoding *Optimizer::x86(int instructionID, const Operand &firstOperand, const Operand &secondOperand, const Operand &thirdOperand)
	{
		return RegisterAllocator::x86(instructionID, firstOperand, secondOperand, thirdOperand);
	}
}