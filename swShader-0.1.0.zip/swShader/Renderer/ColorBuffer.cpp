#include "ColorBuffer.hpp"

namespace swShader
{
	int ColorBuffer::getStride()
	{
		return getWidth();
	}
}