#include "RenderTarget.hpp"

namespace swShader
{
	int RenderTarget::getStride()
	{
		return getWidth();
	}
}