#include "Math.hpp"

namespace swShader
{
	const float M_PI     =  3.14159265e+0f;
	const float M_PI_180 =  1.74532925e-2f;
	const float M_180_PI =  5.72957795e+1f;
	const float M_2PI    =  6.28318530e+0f;
	const float M_PI_2   =  1.57079632e+0f;
}