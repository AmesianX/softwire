#ifdef __cplusplus
extern "C" {
#endif



#define JVERSION	""

#define JCOPYRIGHT	""



#ifdef __cplusplus
}
#endif

