#include "Stream.hpp"

namespace swShader
{
	Stream::Stream()
	{
		type = TYPE_INVALID;
		usage = USAGE_INVALID;
		buffer = 0;
	}

	Stream::Stream(Type type, Usage usage, void **buffer)
	{
		this->type = type;
		this->usage = usage;
		this->buffer = buffer;
	}

	Stream::~Stream()
	{
	}

	Stream::Type Stream::getType() const
	{
		return type;
	}

	Stream::Usage Stream::getUsage() const
	{
		return usage;
	}

	const void *Stream::getBuffer()
	{
		return buffer;
	}

	void Stream::setBuffer(void **buffer)
	{
		this->buffer = buffer;
	}
}