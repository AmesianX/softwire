#ifndef VS_2_0Shader_hpp
#define VS_2_0Shader_hpp

#include "vs20_parser.hpp"

namespace swShader
{
	class VS_2_0Shader : public vs20::vs20_parser
	{
	public:
		VS_2_0Shader(const char *shaderFile);

		~VS_2_0Shader();

	private:
		std::ifstream file;
	};
}

#endif   // VS_2_0Shader_hpp
