#include "PS_2_0Shader.hpp"

namespace swShader
{
	PS_2_0Shader::PS_2_0Shader(const char *shaderFile) : file(shaderFile), ps20::ps20_parser(&file)
	{
		try
		{
			main();
			file.close();
		}
		catch(ps20::ScanException &error)
		{
			throw Error(error.what());
		}
		catch(ps20::ParseException &error)
		{
			throw Error(error.what());
		}
	}

	PS_2_0Shader::~PS_2_0Shader()
	{
	}
}