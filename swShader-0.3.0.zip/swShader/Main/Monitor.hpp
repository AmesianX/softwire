#ifndef swShader_Monitor_hpp
#define swShader_Monitor_hpp

namespace swShader
{
	class Monitor
	{
	public:
		Monitor(float update = 1.0);

		~Monitor();

		float getFrameRate();

		void setUpdateInterval(float update);
		float getUpdateInterval();

		float newFrame();

	private:
		float frameRate;
		float update;

		int frameCount;
		double startTime;
	};
}

#endif   // swShader_Monitor_hpp