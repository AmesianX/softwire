#ifndef Timer_hpp
#define Timer_hpp

namespace swShader
{
	class Timer
	{
	public:
		Timer();

		~Timer();

		static double seconds();
	};
}

#endif   // Timer_hpp