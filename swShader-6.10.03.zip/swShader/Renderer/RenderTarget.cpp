#include "RenderTarget.hpp"

namespace swShader
{
	int RenderTarget::getStride() const
	{
		return getWidth();
	}
}