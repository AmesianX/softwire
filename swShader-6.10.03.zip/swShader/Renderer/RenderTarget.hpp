#ifndef RenderTarget_hpp
#define RenderTarget_hpp

namespace swShader
{
	class RenderTarget
	{
	public:
		virtual void *getColorBuffer() const = 0;
		virtual void *getDepthBuffer() const = 0;
		virtual int getWidth() const = 0;
		virtual int getHeight() const = 0;
		virtual int getStride() const;
		virtual int getBitDepth() const = 0;
	};
}

#endif   // RenderTarget_hpp