#include "VS_2_0Shader.hpp"

namespace swShader
{
	VS_2_0Shader::VS_2_0Shader(const char *shaderFile) : file(shaderFile), vs20_parser(&file)
	{
		try
		{
			main();
			file.close();
		}
		catch(vs20::ScanException &error)
		{
			throw Error(error.what());
		}
		catch(vs20::ParseException &error)
		{
			throw Error(error.what());
		}
	}

	VS_2_0Shader::~VS_2_0Shader()
	{
	}
}