#ifndef PS_2_0Shader_hpp
#define PS_2_0Shader_hpp

#include "ps20_parser.hpp"

namespace swShader
{
	class PS_2_0Shader : public ps20::ps20_parser
	{
	public:
		PS_2_0Shader(const char *shaderFile);

		~PS_2_0Shader();

	private:
		std::ifstream file;
	};
}

#endif   // PS_2_0Shader_hpp
