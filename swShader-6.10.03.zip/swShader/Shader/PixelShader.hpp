#ifndef swShader_PixelShader_hpp
#define swShader_PixelShader_hpp

#include "CodeGenerator.hpp"

namespace swShader
{
	class PixelShader : protected SoftWire::CodeGenerator
	{
	public:
		virtual void execute() = 0;
		virtual void (*executable())() = 0;

		virtual void setConstant(int index, const float value[4]) = 0;
	};
}

#endif swShader_PixelShader_hpp
